import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'src/core/app_router.dart';
import 'src/core/theme.dart';
import 'src/core/settings/settings_controller.dart';

final settingsControllerProvider = ChangeNotifierProvider<SettingsController>((ref) => SettingsController());

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env');
  runApp(const ProviderScope(child: CoinagitchiApp()));
}

class CoinagitchiApp extends ConsumerStatefulWidget {
  const CoinagitchiApp({super.key});
  @override
  ConsumerState<CoinagitchiApp> createState() => _CoinagitchiAppState();
}

class _CoinagitchiAppState extends ConsumerState<CoinagitchiApp> {
  @override
  void initState() {
    super.initState();
    ref.read(settingsControllerProvider).load();
  }

  @override
  Widget build(BuildContext context) {
    final router = ref.watch(routerProvider);
    final mode = ref.watch(settingsControllerProvider).mode;
    return MaterialApp.router(
      title: 'Coinagitchi',
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: mode,
      routerConfig: router,
    );
  }
}
