import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../../main.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ctrl = ref.watch(settingsControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Einstellungen')),
      body: Column(children: [
        RadioListTile<ThemeMode>(
          title: const Text('System'),
          value: ThemeMode.system,
          groupValue: ctrl.mode,
          onChanged: (v) => ref.read(settingsControllerProvider).setMode(v!),
        ),
        RadioListTile<ThemeMode>(
          title: const Text('Hell'),
          value: ThemeMode.light,
          groupValue: ctrl.mode,
          onChanged: (v) => ref.read(settingsControllerProvider).setMode(v!),
        ),
        RadioListTile<ThemeMode>(
          title: const Text('Dunkel'),
          value: ThemeMode.dark,
          groupValue: ctrl.mode,
          onChanged: (v) => ref.read(settingsControllerProvider).setMode(v!),
        ),
      ]),
    );
  }
}
