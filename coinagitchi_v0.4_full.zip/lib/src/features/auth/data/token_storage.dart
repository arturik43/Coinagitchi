import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TokenStorage {
  TokenStorage() : _s = const FlutterSecureStorage();
  final FlutterSecureStorage _s;
  static const _kAccess = 'access_token';
  static const _kRefresh = 'refresh_token';

  Future<void> saveAccess(String token) async => _s.write(key: _kAccess, value: token);
  Future<void> saveRefresh(String token) async => _s.write(key: _kRefresh, value: token);
  Future<String?> getAccess() async => _s.read(key: _kAccess);
  Future<String?> getRefresh() async => _s.read(key: _kRefresh);
  Future<void> clear() async { await _s.delete(key: _kAccess); await _s.delete(key: _kRefresh); }
}
