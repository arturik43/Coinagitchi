import 'package:flutter/foundation.dart';
import '../../../core/http/api_client.dart';
import 'token_storage.dart';

class AuthRepository extends ChangeNotifier {
  AuthRepository(this.api, this.storage);
  final ApiClient api;
  final TokenStorage storage;

  bool _loggedIn = false;
  bool get isLoggedIn => _loggedIn;

  Future<void> login(String email, String password) async {
    final res = await api.login(email, password);
    final access = res['accessToken'] as String?;
    final refresh = res['refreshToken'] as String?;
    if (access == null) throw Exception('No access token');
    await storage.saveAccess(access);
    if (refresh != null) await storage.saveRefresh(refresh);
    _loggedIn = true; notifyListeners();
  }

  Future<void> logout() async { await storage.clear(); _loggedIn = false; notifyListeners(); }
}
