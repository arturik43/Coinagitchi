import 'dart:math';
import '../../pet/domain/pet.dart';

class ActionsService {
  Pet feed(Pet p) {
    return p.copyWith(
      hunger: max(0, p.hunger - 25),
      happy: min(100, p.happy + 10),
      xp: p.xp + 5,
    );
  }

  Pet sleep(Pet p) {
    return p.copyWith(
      energy: min(100, p.energy + 30),
      happy: min(100, p.happy + 5),
      xp: p.xp + 3,
    );
  }

  Pet mine(Pet p) {
    return p.copyWith(
      energy: max(0, p.energy - 15),
      hunger: min(100, p.hunger + 10),
      happy: max(0, p.happy - 5),
      xp: p.xp + 15,
    );
  }
}
