class Pet {
  Pet({
    required this.id,
    required this.name,
    required this.level,
    required this.xp,
    required this.hunger, // 0 = satt, 100 = sehr hungrig
    required this.energy,
    required this.happy,
  });
  final String id;
  final String name;
  final int level;
  final int xp;
  final int hunger; // 0-100
  final int energy; // 0-100
  final int happy;  // 0-100

  Pet copyWith({
    String? id,
    String? name,
    int? level,
    int? xp,
    int? hunger,
    int? energy,
    int? happy,
  }) => Pet(
        id: id ?? this.id,
        name: name ?? this.name,
        level: level ?? this.level,
        xp: xp ?? this.xp,
        hunger: hunger ?? this.hunger,
        energy: energy ?? this.energy,
        happy: happy ?? this.happy,
      );

  factory Pet.fromJson(Map<String, dynamic> j) => Pet(
        id: j['id'] as String,
        name: j['name'] as String,
        level: j['level'] as int,
        xp: j['xp'] as int,
        hunger: j['hunger'] as int,
        energy: j['energy'] as int,
        happy: j['happy'] as int,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'level': level,
        'xp': xp,
        'hunger': hunger,
        'energy': energy,
        'happy': happy,
      };
}
