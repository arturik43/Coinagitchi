import 'dart:async';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../domain/pet.dart';
import '../../actions/application/actions_service.dart';
import '../../../core/http/api_client.dart';
import '../../../core/db/app_database.dart' as db;

class PetState {
  const PetState({required this.pet, this.loading = false});
  final Pet pet;
  final bool loading;
  PetState copyWith({Pet? pet, bool? loading}) =>
      PetState(pet: pet ?? this.pet, loading: loading ?? this.loading);
}

class PetController extends StateNotifier<PetState> {
  PetController({required this.actions, required this.api, required this.db})
      : super(PetState(
          pet: Pet(
            id: 'btc-001',
            name: 'Coinagitchi',
            level: 1,
            xp: 0,
            hunger: 40,
            energy: 70,
            happy: 80,
          ),
        )) {
    _init();
  }

  final ActionsService actions;
  final ApiClient api;
  final db.AppDatabase db;
  Timer? _ticker;

  Future<void> _init() async {
    final cached = await db.getPet();
    if (cached != null) {
      state = state.copyWith(
        pet: Pet(
          id: cached.id,
          name: cached.name,
          level: cached.level,
          xp: cached.xp,
          hunger: cached.hunger,
          energy: cached.energy,
          happy: cached.happy,
        ),
      );
    }
    await refreshFromApi();
    _ticker = Timer.periodic(const Duration(seconds: 30), (_) => _naturalDecay());
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  Future<void> refreshFromApi() async {
    try {
      final json = await api.fetchPet();
      final p = Pet.fromJson(json);
      state = state.copyWith(pet: p);
      await db.upsertPet(db.PetsCompanion.insert(
        id: p.id,
        name: p.name,
        level: p.level,
        xp: p.xp,
        hunger: p.hunger,
        energy: p.energy,
        happy: p.happy,
      ));
    } catch (_) {}
  }

  void _naturalDecay() {
    final p = state.pet;
    final next = p.copyWith(
      hunger: (p.hunger + 5).clamp(0, 100),
      energy: (p.energy - 3).clamp(0, 100),
      happy: (p.happy - 2).clamp(0, 100),
    );
    state = state.copyWith(pet: next);
  }

  Future<void> feed() => _apply('feed', actions.feed);
  Future<void> sleep() => _apply('sleep', actions.sleep);
  Future<void> mine() => _apply('mine', actions.mine);

  Future<void> _apply(String action, Pet Function(Pet) fn) async {
    state = state.copyWith(loading: true);
    try {
      final delta = await api.act(action);
      final p0 = state.pet;
      final p1 = p0.copyWith(
        xp: p0.xp + (delta['xp'] as int? ?? 0),
        hunger: (p0.hunger + (delta['hungerDelta'] as int? ?? 0)).clamp(0, 100),
        energy: (p0.energy + (delta['energyDelta'] as int? ?? 0)).clamp(0, 100),
        happy: (p0.happy + (delta['happyDelta'] as int? ?? 0)).clamp(0, 100),
      );
      final leveled = p1.xp >= (p0.level * 100) ? p1.copyWith(level: p0.level + 1) : p1;
      state = state.copyWith(pet: leveled);
      await db.into(db.actionLogs).insert(db.ActionLogsCompanion.insert(action: action));
      await db.upsertPet(db.PetsCompanion.insert(
        id: leveled.id,
        name: leveled.name,
        level: leveled.level,
        xp: leveled.xp,
        hunger: leveled.hunger,
        energy: leveled.energy,
        happy: leveled.happy,
      ));
    } finally {
      state = state.copyWith(loading: false);
    }
  }
}
