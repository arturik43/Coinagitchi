import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/di.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(petControllerProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Coinagitchi'),
        actions: [
          IconButton(onPressed: () => context.go('/inventory'), icon: const Icon(Icons.inventory_2)),
          IconButton(onPressed: () => context.go('/settings'), icon: const Icon(Icons.settings)),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(state.pet.name, style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),
                Text('Level: ${state.pet.level} | XP: ${state.pet.xp}')
              ]),
            ),
          ),
          const SizedBox(height: 12),
          _Stat(label: 'Hunger', value: state.pet.hunger),
          _Stat(label: 'Energie', value: state.pet.energy),
          _Stat(label: 'Laune', value: state.pet.happy),
          const SizedBox(height: 16),
          Wrap(spacing: 12, children: [
            FilledButton.icon(
              onPressed: state.loading ? null : () => ref.read(petControllerProvider.notifier).feed(),
              icon: const Icon(Icons.fastfood),
              label: const Text('Füttern'),
            ),
            FilledButton.icon(
              onPressed: state.loading ? null : () => ref.read(petControllerProvider.notifier).sleep(),
              icon: const Icon(Icons.bed),
              label: const Text('Schlafen'),
            ),
            FilledButton.icon(
              onPressed: state.loading ? null : () => ref.read(petControllerProvider.notifier).mine(),
              icon: const Icon(Icons.workspace_premium),
              label: const Text('Minen'),
            ),
          ]),
        ]),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});
  final String label;
  final int value;
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label),
        Text('$value/100'),
      ]),
      const SizedBox(height: 6),
      LinearProgressIndicator(value: value / 100),
      const SizedBox(height: 12),
    ]);
  }
}
