import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/di.dart';

class InventoryPage extends ConsumerWidget {
  const InventoryPage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // simple listing via apiClient (mock)
    return Scaffold(
      appBar: AppBar(title: const Text('Inventar')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: ref.read(apiClientProvider).listItems(),
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final items = s.data!;
          return ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final it = items[i];
              return ListTile(
                title: Text(it['name'] as String),
                subtitle: Text('${it['slot']} • ${it['description']}'),
                trailing: Text('x${(it['xpMultiplier'] as num).toStringAsFixed(1)} XP'),
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Ausgewählt: ${it['name']}')),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
