import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/di.dart';

class Item {
  Item({required this.id, required this.name, required this.slot, required this.description, required this.xpMultiplier});
  final String id; final String name; final String slot; final String description; final double xpMultiplier;
  factory Item.fromJson(Map<String, dynamic> j) => Item(
    id: j['id'] as String, name: j['name'] as String, slot: j['slot'] as String, description: j['description'] as String, xpMultiplier: (j['xpMultiplier'] as num).toDouble(),
  );
}

class EquipPage extends ConsumerStatefulWidget {
  const EquipPage({super.key});
  @override
  ConsumerState<EquipPage> createState() => _EquipPageState();
}

class _EquipPageState extends ConsumerState<EquipPage> {
  List<Item> catalog = [];
  Map<String, Item?> equipped = {'HAT': null, 'EYES': null, 'BODY': null};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await ref.read(apiClientProvider).listItems();
    setState(() => catalog = list.map((m) => Item.fromJson(m)).toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ausrüsten')),
      body: Row(children: [
        Expanded(
          child: ListView.builder(
            itemCount: catalog.length,
            itemBuilder: (_, i) {
              final it = catalog[i];
              return Draggable<Item>(
                data: it,
                feedback: Material(child: Chip(label: Text(it.name))),
                child: ListTile(title: Text(it.name), subtitle: Text(it.slot)),
              );
            },
          ),
        ),
        Container(width: 280, padding: const EdgeInsets.all(12), child: Column(children: [
          for (final slot in ['HAT', 'EYES', 'BODY']) _slotWidget(slot),
        ])),
      ]),
    );
  }

  Widget _slotWidget(String slot) {
    return DragTarget<Item>(
      onAccept: (it) async {
        if (it.slot != slot) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Passt nicht in diesen Slot')));
          return;
        }
        setState(() => equipped[slot] = it);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ausgerüstet: ${it.name}')));
      },
      builder: (context, candidate, rejected) {
        final current = equipped[slot];
        return Card(
          child: ListTile(
            leading: Icon(Icons.shield),
            title: Text(slot),
            subtitle: Text(current?.name ?? 'Leer'),
            trailing: current != null
                ? IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => equipped[slot] = null))
                : null,
          ),
        );
      },
    );
  }
}
