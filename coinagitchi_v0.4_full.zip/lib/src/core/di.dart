import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:dio/dio.dart';
import '../core/http/dio_client.dart';
import '../core/http/api_client.dart';
import '../core/env.dart';
import '../features/auth/data/auth_repository.dart';
import '../features/auth/data/token_storage.dart';
import '../features/actions/application/actions_service.dart';
import '../features/pet/application/pet_controller.dart';
import '../core/db/app_database.dart';

final tokenStorageProvider = Provider<TokenStorage>((ref) => TokenStorage());

final dioProvider = Provider<Dio>((ref) {
  final tokens = ref.watch(authTokenProvider);
  final base = Env.apiBaseUrl;
  return DioFactory.create(baseUrl: base, tokens: tokens);
});

final apiClientProvider = Provider<ApiClient>((ref) {
  final dio = ref.watch(dioProvider);
  final mock = Env.appEnv == 'dev' || Env.apiBaseUrl.contains('example');
  return ApiClient(dio, mock: mock);
});

final authTokenProvider = Provider<AuthTokenProvider>((ref) {
  final storage = ref.watch(tokenStorageProvider);
  final api = ref.watch(apiClientProvider);
  return _AuthTokenProviderImpl(storage, api);
});

final authRepositoryProvider = ChangeNotifierProvider<AuthRepository>((ref) => AuthRepository(ref.watch(apiClientProvider), ref.watch(tokenStorageProvider)));

final dbProvider = Provider<AppDatabase>((ref) => AppDatabase());

final actionsServiceProvider = Provider<ActionsService>((ref) => ActionsService());

final petControllerProvider = StateNotifierProvider<PetController, PetState>((ref) {
  final actions = ref.watch(actionsServiceProvider);
  final api = ref.watch(apiClientProvider);
  final db = ref.watch(dbProvider);
  return PetController(actions: actions, api: api, db: db);
});
