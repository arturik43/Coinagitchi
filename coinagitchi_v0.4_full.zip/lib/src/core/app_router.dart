import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../features/auth/presentation/login_page.dart';
import '../features/auth/presentation/onboarding_page.dart';
import '../features/pet/presentation/home_page.dart';
import '../features/settings/presentation/settings_page.dart';
import '../features/items/presentation/inventory_page.dart';
import '../features/leaderboard/presentation/leaderboard_page.dart';
import 'di.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final auth = ref.read(authRepositoryProvider);
  return GoRouter(
    initialLocation: '/onboarding',
    refreshListenable: auth,
    routes: [
      GoRoute(path: '/onboarding', builder: (c, s) => const OnboardingPage()),
      GoRoute(path: '/login', builder: (c, s) => const LoginPage()),
      GoRoute(path: '/', builder: (c, s) => const HomePage()),
      GoRoute(path: '/settings', builder: (c, s) => const SettingsPage()),
      GoRoute(path: '/inventory', builder: (c, s) => const InventoryPage()),
      // Leaderboard page stub (if missing, app still runs)
    ],
    redirect: (context, state) {
      final loggedIn = auth.isLoggedIn;
      final open = {'/onboarding', '/login'}.contains(state.subloc);
      if (!loggedIn && !open) return '/onboarding';
      if (loggedIn && open) return '/';
      return null;
    },
  );
});
