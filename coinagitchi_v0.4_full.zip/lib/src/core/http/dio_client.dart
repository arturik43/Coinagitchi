import 'dart:async';
import 'package:dio/dio.dart';
import '../../features/auth/data/token_storage.dart';
import 'api_client.dart';

abstract class AuthTokenProvider {
  Future<String?> getAccessToken();
  Future<String?> refresh();
}

class DioFactory {
  static Dio create({required String baseUrl, required AuthTokenProvider tokens, Duration timeout = const Duration(seconds: 10)}) {
    final dio = Dio(BaseOptions(baseUrl: baseUrl, connectTimeout: timeout, receiveTimeout: timeout, sendTimeout: timeout, headers: {'Accept': 'application/json'}));

    dio.interceptors.add(InterceptorsWrapper(onRequest: (opt, handler) async {
      final t = await tokens.getAccessToken();
      if (t != null && t.isNotEmpty) opt.headers['Authorization'] = 'Bearer $t';
      handler.next(opt);
    }, onError: (e, handler) async {
      final req = e.requestOptions;
      if (e.response?.statusCode == 401 && req.extra['retried'] != true) {
        try {
          final newToken = await tokens.refresh();
          if (newToken != null) {
            req.extra['retried'] = true;
            req.headers['Authorization'] = 'Bearer $newToken';
            final clone = await dio.fetch(req);
            return handler.resolve(clone);
          }
        } catch (_) {}
      }

      final shouldRetry = e.type != DioExceptionType.cancel && req.extra['retries'] != 3 && (e.response?.statusCode == 429 || (e.response?.statusCode ?? 500) >= 500);
      if (shouldRetry) {
        final current = (req.extra['retries'] as int? ?? 0) + 1;
        final delay = Duration(milliseconds: 300 * (1 << (current - 1)));
        await Future<void>.delayed(delay);
        final newReq = req..extra['retries'] = current;
        try {
          final res = await dio.fetch(newReq);
          return handler.resolve(res);
        } catch (err) {
          return handler.next(err as DioException);
        }
      }

      handler.next(e);
    }));

    return dio;
  }
}

class _AuthTokenProviderImpl extends AuthTokenProvider {
  _AuthTokenProviderImpl(this._storage, this._api);
  final TokenStorage _storage;
  final ApiClient _api;

  @override
  Future<String?> getAccessToken() => _storage.getAccess();

  @override
  Future<String?> refresh() async {
    final refresh = await _storage.getRefresh();
    if (refresh == null) return null;
    try {
      final res = await _api.refreshToken(refresh);
      final access = res['accessToken'] as String?;
      if (access != null) await _storage.saveAccess(access);
      return access;
    } catch (_) {
      await _storage.clear();
      return null;
    }
  }
}
