import 'package:dio/dio.dart';

class ApiClient {
  ApiClient(this._dio, {required this.mock});
  final Dio _dio;
  final bool mock;

  Future<Map<String, dynamic>> login(String email, String password) async {
    if (mock) return {'accessToken': 'dev-access-token', 'refreshToken': 'dev-refresh-token', 'userId': 'u1'};
    final res = await _dio.post('/auth/login', data: {'email': email, 'password': password});
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> refreshToken(String refreshToken) async {
    if (mock) return {'accessToken': 'dev-access-token2'};
    final res = await _dio.post('/auth/refresh', data: {'refreshToken': refreshToken});
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> fetchPet() async {
    if (mock) {
      return {
        'id': 'btc-001',
        'name': 'Coinagitchi',
        'level': 1,
        'xp': 50,
        'hunger': 35,
        'energy': 72,
        'happy': 85,
      };
    }
    final res = await _dio.get('/pets/current');
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> act(String action) async {
    if (mock) {
      switch (action) {
        case 'feed':
          return {'xp': 5, 'hungerDelta': -25, 'energyDelta': 0, 'happyDelta': 10};
        case 'sleep':
          return {'xp': 3, 'hungerDelta': 0, 'energyDelta': +30, 'happyDelta': 5};
        case 'mine':
          return {'xp': 15, 'hungerDelta': +10, 'energyDelta': -15, 'happyDelta': -5};
      }
    }
    final res = await _dio.post('/actions/$action');
    return res.data as Map<String, dynamic>;
  }

  Future<List<Map<String, dynamic>>> listItems() async {
    if (mock) {
      return [
        {'id': 'hat-001', 'name': 'Miner-Helm', 'slot': 'HAT', 'description': 'Glück auf!', 'xpMultiplier': 1.1},
        {'id': 'eyes-001', 'name': 'Laser Eyes', 'slot': 'EYES', 'description': 'HODL‑Blick', 'xpMultiplier': 1.2},
        {'id': 'body-001', 'name': 'Satoshi‑Cape', 'slot': 'BODY', 'description': 'Legendär', 'xpMultiplier': 1.3},
      ];
    }
    final res = await _dio.get('/items');
    return (res.data as List).cast<Map<String, dynamic>>();
  }

  Future<List<Map<String, dynamic>>> leaderboard(String period) async {
    if (mock) {
      return [
        {'rank': 1, 'name': 'Hafida', 'xp': 1234},
        {'rank': 2, 'name': 'Arthur', 'xp': 999},
        {'rank': 3, 'name': 'Master', 'xp': 888},
      ];
    }
    final res = await _dio.get('/leaderboard', queryParameters: {'period': period});
    return (res.data as List).cast<Map<String, dynamic>>();
  }
}
