import 'package:flutter_test/flutter_test.dart';

void main() {
  test('math works', () {
    expect(2 + 2, 4);
  });
}
