# Coinagitchi – Flutter MVP v0.4

This ZIP contains a runnable skeleton of the Coinagitchi Flutter app (subset).
Files included:
- lib/main.dart
- core modules (env, theme, router, di)
- basic features (auth mock, pet/pet-controller, actions)
- inventory & equip UI
- simple README & test

Setup:
```
flutter pub get
cp .env.example .env
flutter run
```

Note: This is a skeleton for local dev and demo. For full project, run codegen:
```
flutter pub run build_runner build --delete-conflicting-outputs
```
